<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Thành viên
                    <small><?php echo e($user->full_name); ?></small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <div class="col-lg-7" style="padding-bottom:120px">
                <?php if(count($errors) > 0): ?>
                  <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($err); ?> <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                <?php endif; ?>

                <?php if(session('thongbao')): ?>
                  <div class="alert alert-success">
                    <?php echo e(session('thongbao')); ?>

                  </div>
                <?php endif; ?>
                
                <form action="admin/user/sua/<?php echo e($user->id); ?>" method="POST">     
                    <input type="hidden" name="_token" value=" <?php echo e(csrf_token()); ?>">         
                    <div class="form-group">
                        <label>Họ tên</label>
                        <input class="form-control" name="full_name" value="<?php echo e($user->full_name); ?>" placeholder="Nhập tên" />
                    </div>
                    <div class="form-group">
                        <label>Số điện thoại</label>
                        <input class="form-control" name="phone" value="<?php echo e($user->phone); ?>" placeholder="Nhập Số điện thoại" />
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" placeholder="Nhập Email" readonly="" />
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" name="password" placeholder="Nhập password" />
                    </div>
                    <div class="form-group">
                        <label>Nhập lại password</label>
                        <input type="password" class="form-control" name="passwordAgain" placeholder="Nhập lại password" />
                    </div>
                   <!--  <div class="form-group">
                        <label>Phân quyền</label>
                        <input class="form-control" name="permission" placeholder="Nhập quyền" />
                    </div> -->
                    <div class="form-group">
                        <label>Địa chỉ</label>
                        <input class="form-control" name="address" value="<?php echo e($user->address); ?>" placeholder="Nhập Địa chỉ" />
                    </div>                    
                    <div class="form-group">
                        <label>Quyền người dùng</label>
                        <label class="radio-inline">
                            <input name="permission" value="0" 
                            <?php if($user->permission == 0): ?>
                              <?php echo e("checked"); ?>

                            <?php endif; ?>
                            type="radio">Thường
                        </label>
                        <label class="radio-inline">
                            <input name="permission" value="1"
                            <?php if($user->permission == 1): ?>
                              <?php echo e("checked"); ?>

                            <?php endif; ?> 
                            type="radio">Admin
                        </label>
                    </div>
                    <button type="submit" class="btn btn-default">Sửa</button>
                    <button type="reset" class="btn btn-default">Reset</button>
                <form>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>