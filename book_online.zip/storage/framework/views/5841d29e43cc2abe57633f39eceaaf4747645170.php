<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Khách Hàng
                    <small><?php echo e($order->customer->name); ?></small>                
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <?php if(session('thongbao')): ?>
                  <div class="alert alert-success">
                    <?php echo e(session('thongbao')); ?>

                  </div>
            <?php endif; ?>
            
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr align="center">
                        <th>Tên sách</th>
                        <th>Số lượng</th>
                        <th>Giá</th>
                        <th>Tổng tiền</th>                        
                    </tr>
                </thead>
                <tbody>
                   <?php $__currentLoopData = $orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd gradeX" align="center">                        
                        <td><?php echo e($o->product->name); ?></td>
                        <td><?php echo e($o->quantity); ?></td>
                        <td><?php echo e($o->unit_price); ?></td>
                        <td><?php echo e($o->quantity * $o->unit_price); ?></td>                     
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

                <tfoot>
                    <tr align="center">
                        <th>Tổng hóa đơn</th>
                        <th><?php echo e($order->total); ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div class="row">
          
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>