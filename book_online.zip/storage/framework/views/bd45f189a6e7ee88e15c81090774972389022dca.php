<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Sách
                    <small><?php echo e($product->name); ?></small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <div class="col-lg-7" style="padding-bottom:120px">
                <?php if(count($errors) > 0): ?>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger">
                      <?php echo e($err); ?> <br>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(session('thongbao')): ?>
                  <div class="alert alert-success">
                    <?php echo e(session('thongbao')); ?>

                  </div>
                <?php endif; ?>

                <form action="admin/product/sua/<?php echo e($product->id); ?>" method="POST">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group">
                        <label>Sách</label>
                        <select class="form-control" name="category">
                            <option value="0">Chọn thể loại sách</option>
                            <?php $__currentLoopData = $theloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tl->id); ?>" 
                              <?php if($product->id_category == $tl->id): ?>
                                <?php echo e("selected"); ?>    
                              <?php endif; ?> ><?php echo e($tl->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tên sách</label>
                        <input class="form-control" name="name" placeholder="Nhập tên sách" value='<?php echo e($product->name); ?>' />
                    </div>

                    <div class="form-group">
                        <label>Tên tác giả</label>
                        <input class="form-control" name="author" placeholder="Nhập tên tác giả" value='<?php echo e($product->author); ?>' />
                    </div>

                    <div class="form-group">
                        <label>Nhà xuất bản</label>
                        <input class="form-control" name="publisher" placeholder="Nhập Nhà xuất bản" value='<?php echo e($product->publisher); ?>' />
                    </div>

                    <div class="form-group">
                        <label>Giá thực</label>
                        <input class="form-control" name="unit_price" placeholder="Nhập giá thực" value='<?php echo e($product->unit_price); ?>' />
                    </div>

                    <div class="form-group">
                        <label>Giá khuyến mãi</label>
                        <input class="form-control" name="promotion_price" placeholder="Nhập giá khuyến mãi" value='<?php echo e($product->promotion_price); ?>' />
                    </div>

                    <div class="form-group">
                        <label>Số lượng</label>
                        <input class="form-control" name="amount" placeholder="Nhập số lượng" value='<?php echo e($product->amount); ?>' />
                    </div>

                    <div class="form-group">
                        <label>Số trang</label>
                        <input class="form-control" name="pages" placeholder="Nhập số trang" value='<?php echo e($product->pages); ?>' />
                    </div>

                    <div class="form-group">
                        <label>Kích thước</label>
                        <input class="form-control" name="book_size" placeholder="Nhập kích thước" value='<?php echo e($product->book_size); ?>' />
                    </div>

                    <div class="form-group">
                        <label>Tên ảnh</label>
                        <input class="form-control" name="image" placeholder="Nhập tên ảnh" value='<?php echo e($product->image); ?>' />
                    </div>

                    <div class="form-group">
                        <label>Năm xuất bản</label>
                        <input class="form-control" name="year_publish" placeholder="Nhập Năm xuất bản" value='<?php echo e($product->year_publish); ?>' />
                    </div>

                    <div class="form-group">
                        <label>Mô tả</label>
                        <input class="form-control" name="description" placeholder="Nhập mô tả" value='<?php echo e($product->description); ?>' />
                    </div>
                    
                    <button type="submit" class="btn btn-default">Sửa</button>
                    <button type="reset" class="btn btn-default">Reset</button>
                <form>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>