<?php $__env->startSection('content'); ?>

<div class="inner-header">
	<div class="container">
		<div class="pull-left">
			<h6 class="inner-title"><?php echo e($loai_sp->name); ?></h6>
		</div>
		<div class="pull-right">
			<div class="beta-breadcrumb font-large">
				<a href="<?php echo e(route('trangchu')); ?>">Trang chủ</a> / <span>Loại Sản phẩm</span>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
	
<div class="container">
		<div id="content" class="space-top-none">
			<div class="main-content">
				<div class="space60">&nbsp;</div>
				<div class="row">
					<div class="col-sm-3">
						<ul class="aside-menu">
							<?php $__currentLoopData = $loai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <li><a href="<?php echo e(route('loaisanpham', $l->id)); ?>"><?php echo e($l->name); ?></a></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<div class="col-sm-9">
						<div class="beta-products-list">
							<h4>Sản phẩm mới</h4>
							<div class="beta-products-details">
								<!-- <p class="pull-left">Co <?php echo e(count($sp_theoloai)); ?> san pham</p> -->
								<div class="clearfix"></div>
							</div>

							<div class="row">
								<?php $__currentLoopData = $sp_theoloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								  <div class="col-sm-4">
									<div class="single-item">
										<?php if($sp->promotion_price != 0): ?>
										  <div class="ribbon-wrapper"><div class="ribbon sale">Sale</div></div>
									    <?php endif; ?>
										<div class="single-item-header">
											<a href="chi-tiet-san-pham/<?php echo e($sp->id); ?>"><img class="" src="source/image/product/<?php echo e($sp->image); ?>" alt="" height="250px"></a>
										</div>
										<div class="single-item-body">
											<p class="single-item-title"><?php echo e($sp->name); ?></p>
											<p class="single-item-price">
											  <?php if($sp->promotion_price != 0): ?>
											    <span class="flash-del"><?php echo e($sp->unit_price); ?> VND</span>
											    <span class="flash-sale"><?php echo e($sp->promotion_price); ?> VND</span>
											  <?php else: ?>
											    <span class="flash-sale"><?php echo e($sp->unit_price); ?> VND</span>
											  <?php endif; ?>
											</p>
										</div>
										<div class="single-item-caption">
											<?php if($sp->amount <= 5): ?>
									          <i class="beta-btn primary">Hết hàng</i>
										    <?php else: ?>
											<a class="add-to-cart pull-left" href="<?php echo e(route('themgiohang', $sp->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<?php endif; ?>
											<a class="beta-btn primary" href="product.html">Details <i class="fa fa-chevron-right"></i></a>
											<div class="clearfix"></div>
										</div>
									</div>
								  </div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							  <div class="row">
							    <?php echo e($sp_theoloai->links()); ?>

							  </div>  	
							</div>							

						<div class="space50">&nbsp;</div>

						<div class="beta-products-list">
							<h4>Sản phẩm khác</h4>
							<div class="beta-products-details">
								<!-- <p class="pull-left">Tim thay <?php echo e(count($sp_khac)); ?> san pham</p> -->
								<div class="clearfix"></div>
							</div>
							<div class="row">
								<?php $__currentLoopData = $sp_khac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp_k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								  <div class="col-sm-4">
									<div class="single-item">
										<?php if($sp_k->promotion_price != 0): ?>
										  <div class="ribbon-wrapper"><div class="ribbon sale">Sale</div></div>
									    <?php endif; ?>
										<div class="single-item-header">
											<a href="<?php echo e(route('chitietsanpham',$sp_k->id)); ?>"><img src="source/image/product/<?php echo e($sp_k->image); ?>" alt="" height="250px"></a>
										</div>
										<div class="single-item-body">
											<p class="single-item-title"><?php echo e($sp_k->name); ?></p>
											<p class="single-item-price">
											  <?php if($sp_k->promotion_price != 0): ?>
											    <span class="flash-del"><?php echo e($sp_k->unit_price); ?> VND</span>
											    <span class="flash-sale"><?php echo e($sp_k->promotion_price); ?> VND</span>
											  <?php else: ?>
											    <span class="flash-sale"><?php echo e($sp_k->unit_price); ?> VND</span>
											  <?php endif; ?>
											</p>
										</div>
										<div class="single-item-caption">
											<?php if($sp_k->amount <= 5): ?>
									  		  <i class="beta-btn primary">Hết hàng</i>
											<?php else: ?>
											<a class="add-to-cart pull-left" href="<?php echo e(route('themgiohang', $sp_k->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<?php endif; ?>
											<a class="beta-btn primary" href="<?php echo e(route('chitietsanpham', $sp_k->id)); ?>">Details <i class="fa fa-chevron-right"></i></a>
											<div class="clearfix"></div>
										</div>
									</div>
								  </div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>

							<div class="row">
							  <?php echo e($sp_khac->links()); ?>

							</div>
							<div class="space40">&nbsp;</div>
							
						</div> <!-- .beta-products-list -->
					</div>
				</div> <!-- end section with sidebar and main content -->


			</div> <!-- .main-content -->
		</div> <!-- #content -->
</div> <!-- .container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>